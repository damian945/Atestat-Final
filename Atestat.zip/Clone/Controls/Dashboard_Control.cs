﻿using System;
using System.Drawing;
using System.Windows.Forms;
using System.Windows.Forms.DataVisualization.Charting;
using Atestat.Transactions;

namespace Atestat.Controls
{
    public partial class Dashboard_Control: UserControl
    {
        public Dashboard_Control()
        {
            InitializeComponent();
        }

        private void chart1_Click(object sender, EventArgs e)
        {

        }

        private void Dashboard_Control_Load(object sender, EventArgs e)
        {
            LoadPieChart();
            LoadLineChart();
        }

        public void LoadPieChart()
        {
            // 0) Clear any existing titles
            chart1.Titles.Clear();

            // 1) Create and style the title
            var title = new Title
            {
                Text = "Last Month's Expenses",
                Font = new Font("Nirmala UI", 14f, FontStyle.Bold),
                ForeColor = Color.FromArgb(116, 86, 174),
                Docking = Docking.Top,
                Alignment = ContentAlignment.MiddleCenter,
                IsDockedInsideChartArea = false
            };

            // 2) Add it to the chart
            chart1.Titles.Add(title);

            // 1) Fetch the data
            var dt = TransactionRepository.Instance.GetMonthlyExpensesByCategory();

            // 2) Clear existing series and set up ChartArea for flat look
            chart1.Series.Clear();
            var ca = chart1.ChartAreas[0];
            ca.BackColor = Color.White;           // flat white background
            ca.BorderWidth = 0;
            ca.BorderColor = Color.Transparent;
            ca.Area3DStyle.Enable3D = false;                // no 3D
            ca.ShadowOffset = 0;                     // no shadow

            // Draw a flat purple border around the entire chart control:
            chart1.BorderlineDashStyle = ChartDashStyle.Solid;
            chart1.BorderlineColor = Color.FromArgb(116, 86, 174);
            chart1.BorderlineWidth = 2;

            // 3) Create and style series for flat slices
            var series = new Series("Expenses")
            {
                ChartType = SeriesChartType.Pie,
                BorderColor = Color.White,            // white separators
                BorderWidth = 1,
                BackGradientStyle = GradientStyle.None,     // no gradient
                Font = new Font("Nirmala UI", 10f, FontStyle.Regular) // slice labels
            };
            series["PieDrawingStyle"] = "Default";          // flat edges
            series["PieLineColor"] = "White";            // white slice borders
            series["PieLabelStyle"] = "Outside";
            series.Label = "#PERCENT{P1}\n#VALX";

            // 4) Assign a flat purple palette (main color first)
            chart1.Palette = ChartColorPalette.None;
            chart1.PaletteCustomColors = new[]
            {
                Color.FromArgb(116,  86, 174),   // main purple
                Color.FromArgb(153,  51, 153),
                Color.FromArgb(178, 102, 178),
                Color.FromArgb(204, 153, 204),
                Color.FromArgb(230, 179, 230),
            };

            // 5) Bind data
            series.XValueMember = "CategoryName";
            series.YValueMembers = "TotalAmount";
            chart1.DataSource = dt;
            chart1.Series.Add(series);
            chart1.DataBind();

            // 6) Style and position legend flat with Nirmala UI
            var lg = chart1.Legends[0];
            lg.Enabled = true;
            //lg.Docking = Docking.None;  // we'll position manually
            lg.BackColor = Color.White;
            lg.BorderColor = Color.Transparent;
            lg.Font = new Font("Nirmala UI", 9f, FontStyle.Regular);
            lg.LegendStyle = LegendStyle.Table;
            lg.TableStyle = LegendTableStyle.Wide;
            lg.Title = "Categories";
            lg.TitleFont = new Font("Nirmala UI", 10f, FontStyle.Bold);

            // 7) Allocate space: make pie chart larger and legend smaller
            // ChartArea: x=5%, y=5%, width=70%, height=90%
            ca.Position = new ElementPosition(5, 5, 70, 90);
            // Legend: x=78%, y=10%, width=20%, height=80%
            lg.Position = new ElementPosition(78, 10, 20, 80);
        }

        public void LoadLineChart()
        {
            // 0) Clear any existing titles
            chart2.Titles.Clear();

            // 1) Create and style the title
            var title = new Title
            {
                Text = "Income vs. Expenses Over Last Year",
                Font = new Font("Nirmala UI", 14f, FontStyle.Bold),
                ForeColor = Color.FromArgb(116, 86, 174),
                Docking = Docking.Top,
                Alignment = ContentAlignment.MiddleCenter,
                IsDockedInsideChartArea = false
            };

            // 2) Add it to the chart
            chart2.Titles.Add(title);

            // 1) Fetch the data
            var dt = TransactionRepository.Instance.GetLastYearIncomeVsExpensesByMonth();

            // 2) Clear existing series and configure ChartArea on chart2
            chart2.Series.Clear();
            var ca = chart2.ChartAreas[0];
            ca.BackColor = Color.White;
            ca.BorderWidth = 0;
            ca.BorderColor = Color.Transparent;
            ca.Area3DStyle.Enable3D = false;
            ca.AxisX.MajorGrid.Enabled = false;
            ca.AxisY.MajorGrid.Enabled = false;

            // Draw a flat purple border around the entire chart control:
            chart2.BorderlineDashStyle = ChartDashStyle.Solid;
            chart2.BorderlineColor = Color.FromArgb(116, 86, 174);
            chart2.BorderlineWidth = 2;

            // apply Nirmala UI to axes
            var axisFont = new Font("Nirmala UI", 10f, FontStyle.Regular);
            ca.AxisX.Title = "Month";
            ca.AxisX.TitleFont = axisFont;
            ca.AxisX.LabelStyle = new LabelStyle { Font = axisFont };
            ca.AxisY.Title = "Amount";
            ca.AxisY.TitleFont = axisFont;
            ca.AxisY.LabelStyle = new LabelStyle { Font = axisFont };

            // 3) Create Income series (main purple)
            var inc = new Series("Income")
            {
                ChartType = SeriesChartType.Line,
                BorderWidth = 3,
                Color = Color.FromArgb(116, 86, 174),
                MarkerStyle = MarkerStyle.Circle,
                MarkerSize = 7,
                Font = new Font("Nirmala UI", 10f, FontStyle.Regular),
                XValueMember = "Month",
                YValueMembers = "TotalIncome"
            };
            chart2.Series.Add(inc);

            // 4) Create Expense series (secondary purple)
            var exp = new Series("Expenses")
            {
                ChartType = SeriesChartType.Line,
                BorderWidth = 3,
                Color = Color.FromArgb(153, 51, 153),
                MarkerStyle = MarkerStyle.Square,
                MarkerSize = 7,
                Font = new Font("Nirmala UI", 10f, FontStyle.Regular),
                XValueMember = "Month",
                YValueMembers = "TotalExpense"
            };
            chart2.Series.Add(exp);

            // 5) Bind and finalize axes
            chart2.DataSource = dt;
            ca.AxisX.Interval = 1;
            ca.AxisX.Minimum = 1;
            ca.AxisX.Maximum = 12;
            chart2.DataBind();

            // 6) Style legend on chart2
            var lg = chart2.Legends[0];
            lg.Enabled = true;
            lg.Docking = Docking.Top;
            lg.BackColor = Color.White;
            lg.BorderColor = Color.Transparent;
            lg.LegendStyle = LegendStyle.Row;
            lg.Alignment = StringAlignment.Center;
            lg.Font = new Font("Nirmala UI", 10f, FontStyle.Regular);

            // 7) Apply overall chart font
            chart2.Font = new Font("Nirmala UI", 10f, FontStyle.Regular);
        }


    }
}
