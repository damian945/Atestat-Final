﻿using System;
using System.Drawing;
using System.Windows.Forms;
using Atestat.Transactions;
using Atestat.Repos;
using Atestat.Manager;

namespace Atestat.Controls
{
    public partial class Transactions_Control: UserControl
    {
        public Transactions_Control()
        {
            InitializeComponent();
        }

        //Add Transaction button
        private void add_button_Click(object sender, EventArgs e)
        {
            using (var transactionWizard = new TransactionWizard())
            {
                // Show dialog and check if an operation was completed
                if (transactionWizard.ShowDialog() == DialogResult.OK)
                {
                    // Re-load the transactions after the wizard closes successfully
                    dataGridTransactions.DataSource = TransactionRepository.Instance.LoadTransactions();

                    LoadPbLabels();
                }
            }
        }

        // Format the dataGridView
        private void Transactions_Control_Load(object sender, EventArgs e)
        {
            dataGridTransactions.EnableHeadersVisualStyles = false;

            dataGridTransactions.ColumnHeadersDefaultCellStyle.BackColor = Color.FromArgb(116, 86, 174);
            dataGridTransactions.ColumnHeadersDefaultCellStyle.Font = new Font("Nirmala UI", 8, FontStyle.Bold);
            dataGridTransactions.ColumnHeadersDefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;

            dataGridTransactions.DataSource = TransactionRepository.Instance.LoadTransactions();

            incomeTarget_lbl.Text = incomeTarget_lbl.Text + " " + BudgetManager.Instance.CurrentBudget.IncomeTarget.ToString();
            spendingTrg_lbl.Text = spendingTrg_lbl.Text + " " + BudgetManager.Instance.CurrentBudget.SpendingLimit.ToString();
            SavingTrg_lbl.Text = SavingTrg_lbl.Text + " " + BudgetManager.Instance.CurrentBudget.SavingsTarget.ToString();

            LoadPbLabels();
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void dataGridTransactions_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        // Delete Transaction button
        private void button1_Click(object sender, EventArgs e)
        {
            if (dataGridTransactions.SelectedRows.Count > 0)
            {
                // A full row is selected; proceed with the action.
                DataGridViewRow selectedRow = dataGridTransactions.SelectedRows[0];

                // Asking if you're sure about the deletion
                if (MessageBox.Show("Are you sure you want to delete this transaction?",
                        "Confirm Deletion",
                        MessageBoxButtons.YesNo,
                        MessageBoxIcon.Question) == DialogResult.Yes)
                {
                    TransactionRepository.Instance.DeleteTransaction(selectedRow);
                    dataGridTransactions.DataSource = TransactionRepository.Instance.LoadTransactions();
                    LoadPbLabels();
                }
            }
            else
            {
                // Optionally, notify the user if no full row is selected.
                MessageBox.Show("Please select an entire row to proceed.");
            }
        }

        // Edit Transaction button
        private void button2_Click(object sender, EventArgs e)
        {
            if (dataGridTransactions.SelectedRows.Count > 0)
            {
                // A full row is selected; proceed with the action.
                DataGridViewRow selectedRow = dataGridTransactions.SelectedRows[0];

                using (var editTransactionWizard = new EditTransactionWizard(selectedRow))
                {
                    // Show dialog and check if an operation was completed
                    if (editTransactionWizard.ShowDialog() == DialogResult.OK)
                    {
                        // Re-load the transactions after the wizard closes successfully
                        dataGridTransactions.DataSource = TransactionRepository.Instance.LoadTransactions();
                        LoadPbLabels();
                    }
                }

            }
            else
            {
                // Optionally, notify the user if no full row is selected.
                MessageBox.Show("Please select an entire row to proceed.");
            }
        }

        // Load Transactions Button
        private void TrList_btn_Click(object sender, EventArgs e)
        {
            dataGridTransactions.DataSource = TransactionRepository.Instance.LoadTransactions();
        }

        // Load subscriptions button
        private void SbList_btn_Click(object sender, EventArgs e)
        {
            dataGridTransactions.DataSource = SubscriptionRepository.Instance.LoadSubscriptions();
        }

        // Add subscription button
        private void button5_Click(object sender, EventArgs e)
        {
            using (var subscriptionWizard = new SubscriptionWizard())
            {
                // Show dialog and check if an operation was completed
                if (subscriptionWizard.ShowDialog() == DialogResult.OK)
                {
                    // Re-load the transactions after the wizard closes successfully
                    dataGridTransactions.DataSource = SubscriptionRepository.Instance.LoadSubscriptions();
                    LoadPbLabels();
                }
            }
        }

        // Delete subscription button
        private void button4_Click(object sender, EventArgs e)
        {
            if (dataGridTransactions.SelectedRows.Count > 0)
            {
                // A full row is selected; proceed with the action.
                DataGridViewRow selectedRow = dataGridTransactions.SelectedRows[0];

                // Asking if you're sure about the deletion
                if (MessageBox.Show("Are you sure you want to delete this subscriptions?",
                        "Confirm Deletion",
                        MessageBoxButtons.YesNo,
                        MessageBoxIcon.Question) == DialogResult.Yes)
                {
                    SubscriptionRepository.Instance.DeleteSubscription(selectedRow);
                    dataGridTransactions.DataSource = SubscriptionRepository.Instance.LoadSubscriptions();
                    LoadPbLabels();
                }
            }
            else
            {
                // Notify the user if no full row is selected.
                MessageBox.Show("Please select an entire row to proceed.");
            }
        }

        // Edit Subscription button
        private void button3_Click(object sender, EventArgs e)
        {
            if (dataGridTransactions.SelectedRows.Count > 0)
            {
                // A full row is selected; proceed with the action.
                DataGridViewRow selectedRow = dataGridTransactions.SelectedRows[0];

                using (var editSubscriptionWizard = new EditSubscriptionWizard(selectedRow))
                {
                    // Show dialog and check if an operation was completed
                    if (editSubscriptionWizard.ShowDialog() == DialogResult.OK)
                    {
                        // Re-load the transactions after the wizard closes successfully
                        dataGridTransactions.DataSource = SubscriptionRepository.Instance.LoadSubscriptions();
                        LoadPbLabels();
                    }
                }

            }
            else
            {
                // Optionally, notify the user if no full row is selected.
                MessageBox.Show("Please select an entire row to proceed.");
            }
        }
    
        public void LoadPbLabels()
        {
            ProgressBars_Repository.Instance.LoadValues();
            label3.Text = ProgressBars_Repository.Instance.currentIncome.ToString();
            label4.Text = ProgressBars_Repository.Instance.currentExpenses.ToString();

            IncomePgBar.Value = ProgressBars_Repository.Instance.LoadIncomeBars();
            ExpensesPgBar.Value = ProgressBars_Repository.Instance.LoadExpenseBar();
            progressBar1.Value = ProgressBars_Repository.Instance.LoadSavingsBar();
        }

        private void IncomePanel_Paint(object sender, PaintEventArgs e)
        {

        }

        private void IncomePgBar_Click(object sender, EventArgs e)
        {

        }
    }
}
