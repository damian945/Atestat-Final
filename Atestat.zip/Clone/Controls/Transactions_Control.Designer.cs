﻿namespace Atestat.Controls
{
    partial class Transactions_Control
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            this.add_button = new System.Windows.Forms.Button();
            this.dataGridTransactions = new System.Windows.Forms.DataGridView();
            this.lbl_TransactionManager = new System.Windows.Forms.Label();
            this.IncomePanel = new System.Windows.Forms.Panel();
            this.IncomePgBar = new System.Windows.Forms.ProgressBar();
            this.incomeTarget_lbl = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.totalInc_label = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.ExpensesPanel = new System.Windows.Forms.Panel();
            this.ExpensesPgBar = new System.Windows.Forms.ProgressBar();
            this.spendingTrg_lbl = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.totalExp_label = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.lbl_SubscriptionManager = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.progressBar1 = new System.Windows.Forms.ProgressBar();
            this.SavingTrg_lbl = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.panel3 = new System.Windows.Forms.Panel();
            this.TrList_btn = new System.Windows.Forms.Button();
            this.SbList_btn = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridTransactions)).BeginInit();
            this.IncomePanel.SuspendLayout();
            this.ExpensesPanel.SuspendLayout();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel3.SuspendLayout();
            this.SuspendLayout();
            // 
            // add_button
            // 
            this.add_button.BackColor = System.Drawing.Color.Thistle;
            this.add_button.Cursor = System.Windows.Forms.Cursors.Hand;
            this.add_button.FlatAppearance.BorderColor = System.Drawing.Color.Thistle;
            this.add_button.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.add_button.Font = new System.Drawing.Font("Nirmala UI", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.add_button.ForeColor = System.Drawing.Color.Indigo;
            this.add_button.Location = new System.Drawing.Point(10, 40);
            this.add_button.Name = "add_button";
            this.add_button.Size = new System.Drawing.Size(118, 23);
            this.add_button.TabIndex = 2;
            this.add_button.Text = "Add Transaction";
            this.add_button.UseVisualStyleBackColor = false;
            this.add_button.Click += new System.EventHandler(this.add_button_Click);
            // 
            // dataGridTransactions
            // 
            this.dataGridTransactions.AllowUserToAddRows = false;
            this.dataGridTransactions.AllowUserToDeleteRows = false;
            this.dataGridTransactions.AllowUserToResizeColumns = false;
            this.dataGridTransactions.AllowUserToResizeRows = false;
            this.dataGridTransactions.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridTransactions.BackgroundColor = System.Drawing.Color.White;
            this.dataGridTransactions.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dataGridTransactions.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.None;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(116)))), ((int)(((byte)(86)))), ((int)(((byte)(174)))));
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Nirmala UI", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.Color.MediumPurple;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridTransactions.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dataGridTransactions.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.Color.MediumPurple;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridTransactions.DefaultCellStyle = dataGridViewCellStyle2;
            this.dataGridTransactions.Location = new System.Drawing.Point(415, 13);
            this.dataGridTransactions.MultiSelect = false;
            this.dataGridTransactions.Name = "dataGridTransactions";
            this.dataGridTransactions.ReadOnly = true;
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(116)))), ((int)(((byte)(86)))), ((int)(((byte)(174)))));
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Nirmala UI", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.Color.MediumPurple;
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridTransactions.RowHeadersDefaultCellStyle = dataGridViewCellStyle3;
            this.dataGridTransactions.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridTransactions.Size = new System.Drawing.Size(586, 386);
            this.dataGridTransactions.TabIndex = 3;
            this.dataGridTransactions.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridTransactions_CellContentClick);
            // 
            // lbl_TransactionManager
            // 
            this.lbl_TransactionManager.AutoSize = true;
            this.lbl_TransactionManager.Font = new System.Drawing.Font("Microsoft YaHei UI", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_TransactionManager.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(116)))), ((int)(((byte)(86)))), ((int)(((byte)(174)))));
            this.lbl_TransactionManager.Location = new System.Drawing.Point(3, 9);
            this.lbl_TransactionManager.Name = "lbl_TransactionManager";
            this.lbl_TransactionManager.Size = new System.Drawing.Size(237, 28);
            this.lbl_TransactionManager.TabIndex = 4;
            this.lbl_TransactionManager.Text = "Transaction Manager";
            // 
            // IncomePanel
            // 
            this.IncomePanel.BackColor = System.Drawing.Color.White;
            this.IncomePanel.Controls.Add(this.IncomePgBar);
            this.IncomePanel.Controls.Add(this.incomeTarget_lbl);
            this.IncomePanel.Controls.Add(this.label3);
            this.IncomePanel.Controls.Add(this.totalInc_label);
            this.IncomePanel.Controls.Add(this.label1);
            this.IncomePanel.ForeColor = System.Drawing.Color.LightGray;
            this.IncomePanel.Location = new System.Drawing.Point(16, 223);
            this.IncomePanel.Name = "IncomePanel";
            this.IncomePanel.Size = new System.Drawing.Size(186, 102);
            this.IncomePanel.TabIndex = 5;
            this.IncomePanel.Paint += new System.Windows.Forms.PaintEventHandler(this.IncomePanel_Paint);
            // 
            // IncomePgBar
            // 
            this.IncomePgBar.Location = new System.Drawing.Point(7, 62);
            this.IncomePgBar.Name = "IncomePgBar";
            this.IncomePgBar.Size = new System.Drawing.Size(157, 23);
            this.IncomePgBar.Step = 1;
            this.IncomePgBar.Style = System.Windows.Forms.ProgressBarStyle.Continuous;
            this.IncomePgBar.TabIndex = 6;
            this.IncomePgBar.Click += new System.EventHandler(this.IncomePgBar_Click);
            // 
            // incomeTarget_lbl
            // 
            this.incomeTarget_lbl.AutoSize = true;
            this.incomeTarget_lbl.Font = new System.Drawing.Font("Microsoft YaHei UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.incomeTarget_lbl.ForeColor = System.Drawing.Color.Gray;
            this.incomeTarget_lbl.Location = new System.Drawing.Point(7, 25);
            this.incomeTarget_lbl.Name = "incomeTarget_lbl";
            this.incomeTarget_lbl.Size = new System.Drawing.Size(100, 17);
            this.incomeTarget_lbl.TabIndex = 6;
            this.incomeTarget_lbl.Text = "Income Target:";
            this.incomeTarget_lbl.Click += new System.EventHandler(this.label3_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft YaHei UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.Gray;
            this.label3.Location = new System.Drawing.Point(98, 42);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(14, 17);
            this.label3.TabIndex = 6;
            this.label3.Text = "*";
            this.label3.Click += new System.EventHandler(this.label3_Click);
            // 
            // totalInc_label
            // 
            this.totalInc_label.AutoSize = true;
            this.totalInc_label.Font = new System.Drawing.Font("Microsoft YaHei UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.totalInc_label.ForeColor = System.Drawing.Color.Gray;
            this.totalInc_label.Location = new System.Drawing.Point(7, 42);
            this.totalInc_label.Name = "totalInc_label";
            this.totalInc_label.Size = new System.Drawing.Size(96, 17);
            this.totalInc_label.TabIndex = 6;
            this.totalInc_label.Text = "Total income: ";
            this.totalInc_label.Click += new System.EventHandler(this.label3_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft YaHei UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(116)))), ((int)(((byte)(86)))), ((int)(((byte)(174)))));
            this.label1.Location = new System.Drawing.Point(2, 2);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(162, 26);
            this.label1.TabIndex = 4;
            this.label1.Text = "Income Balance";
            // 
            // ExpensesPanel
            // 
            this.ExpensesPanel.BackColor = System.Drawing.Color.White;
            this.ExpensesPanel.Controls.Add(this.ExpensesPgBar);
            this.ExpensesPanel.Controls.Add(this.spendingTrg_lbl);
            this.ExpensesPanel.Controls.Add(this.label4);
            this.ExpensesPanel.Controls.Add(this.totalExp_label);
            this.ExpensesPanel.Controls.Add(this.label2);
            this.ExpensesPanel.ForeColor = System.Drawing.Color.LightGray;
            this.ExpensesPanel.Location = new System.Drawing.Point(208, 223);
            this.ExpensesPanel.Name = "ExpensesPanel";
            this.ExpensesPanel.Size = new System.Drawing.Size(185, 102);
            this.ExpensesPanel.TabIndex = 5;
            // 
            // ExpensesPgBar
            // 
            this.ExpensesPgBar.Location = new System.Drawing.Point(7, 62);
            this.ExpensesPgBar.Name = "ExpensesPgBar";
            this.ExpensesPgBar.Size = new System.Drawing.Size(157, 23);
            this.ExpensesPgBar.TabIndex = 6;
            // 
            // spendingTrg_lbl
            // 
            this.spendingTrg_lbl.AutoSize = true;
            this.spendingTrg_lbl.Font = new System.Drawing.Font("Microsoft YaHei UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.spendingTrg_lbl.ForeColor = System.Drawing.Color.Gray;
            this.spendingTrg_lbl.Location = new System.Drawing.Point(3, 25);
            this.spendingTrg_lbl.Name = "spendingTrg_lbl";
            this.spendingTrg_lbl.Size = new System.Drawing.Size(102, 17);
            this.spendingTrg_lbl.TabIndex = 6;
            this.spendingTrg_lbl.Text = "Spending limit:";
            this.spendingTrg_lbl.Click += new System.EventHandler(this.label3_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft YaHei UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.Gray;
            this.label4.Location = new System.Drawing.Point(104, 42);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(14, 17);
            this.label4.TabIndex = 6;
            this.label4.Text = "*";
            this.label4.Click += new System.EventHandler(this.label3_Click);
            // 
            // totalExp_label
            // 
            this.totalExp_label.AutoSize = true;
            this.totalExp_label.Font = new System.Drawing.Font("Microsoft YaHei UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.totalExp_label.ForeColor = System.Drawing.Color.Gray;
            this.totalExp_label.Location = new System.Drawing.Point(3, 42);
            this.totalExp_label.Name = "totalExp_label";
            this.totalExp_label.Size = new System.Drawing.Size(107, 17);
            this.totalExp_label.TabIndex = 6;
            this.totalExp_label.Text = "Total expenses: ";
            this.totalExp_label.Click += new System.EventHandler(this.label3_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft YaHei UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(116)))), ((int)(((byte)(86)))), ((int)(((byte)(174)))));
            this.label2.Location = new System.Drawing.Point(2, 2);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(170, 26);
            this.label2.TabIndex = 4;
            this.label2.Text = "Expense Balance";
            // 
            // lbl_SubscriptionManager
            // 
            this.lbl_SubscriptionManager.AutoSize = true;
            this.lbl_SubscriptionManager.Font = new System.Drawing.Font("Microsoft YaHei UI", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_SubscriptionManager.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(116)))), ((int)(((byte)(86)))), ((int)(((byte)(174)))));
            this.lbl_SubscriptionManager.Location = new System.Drawing.Point(3, 9);
            this.lbl_SubscriptionManager.Name = "lbl_SubscriptionManager";
            this.lbl_SubscriptionManager.Size = new System.Drawing.Size(247, 28);
            this.lbl_SubscriptionManager.TabIndex = 4;
            this.lbl_SubscriptionManager.Text = "Subscription Manager";
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.Thistle;
            this.button1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button1.FlatAppearance.BorderColor = System.Drawing.Color.Thistle;
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.Font = new System.Drawing.Font("Nirmala UI", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.ForeColor = System.Drawing.Color.Indigo;
            this.button1.Location = new System.Drawing.Point(132, 40);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(118, 23);
            this.button1.TabIndex = 6;
            this.button1.Text = "Delete Transaction";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.Thistle;
            this.button2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button2.FlatAppearance.BorderColor = System.Drawing.Color.Thistle;
            this.button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button2.Font = new System.Drawing.Font("Nirmala UI", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.ForeColor = System.Drawing.Color.Indigo;
            this.button2.Location = new System.Drawing.Point(253, 40);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(118, 23);
            this.button2.TabIndex = 6;
            this.button2.Text = "Edit Transaction";
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button3
            // 
            this.button3.BackColor = System.Drawing.Color.Thistle;
            this.button3.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button3.FlatAppearance.BorderColor = System.Drawing.Color.Thistle;
            this.button3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button3.Font = new System.Drawing.Font("Nirmala UI", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button3.ForeColor = System.Drawing.Color.Indigo;
            this.button3.Location = new System.Drawing.Point(253, 41);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(118, 23);
            this.button3.TabIndex = 6;
            this.button3.Text = "Edit Subscription";
            this.button3.UseVisualStyleBackColor = false;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // button4
            // 
            this.button4.BackColor = System.Drawing.Color.Thistle;
            this.button4.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button4.FlatAppearance.BorderColor = System.Drawing.Color.Thistle;
            this.button4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button4.Font = new System.Drawing.Font("Nirmala UI", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button4.ForeColor = System.Drawing.Color.Indigo;
            this.button4.Location = new System.Drawing.Point(132, 41);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(118, 23);
            this.button4.TabIndex = 6;
            this.button4.Text = "Delete Subscription";
            this.button4.UseVisualStyleBackColor = false;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // button5
            // 
            this.button5.BackColor = System.Drawing.Color.Thistle;
            this.button5.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button5.FlatAppearance.BorderColor = System.Drawing.Color.Thistle;
            this.button5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button5.Font = new System.Drawing.Font("Nirmala UI", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button5.ForeColor = System.Drawing.Color.Indigo;
            this.button5.Location = new System.Drawing.Point(10, 41);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(118, 23);
            this.button5.TabIndex = 6;
            this.button5.Text = "Add Subscription";
            this.button5.UseVisualStyleBackColor = false;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.White;
            this.panel1.Controls.Add(this.progressBar1);
            this.panel1.Controls.Add(this.SavingTrg_lbl);
            this.panel1.Controls.Add(this.label6);
            this.panel1.ForeColor = System.Drawing.Color.LightGray;
            this.panel1.Location = new System.Drawing.Point(16, 331);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(377, 70);
            this.panel1.TabIndex = 5;
            // 
            // progressBar1
            // 
            this.progressBar1.Location = new System.Drawing.Point(7, 31);
            this.progressBar1.Name = "progressBar1";
            this.progressBar1.Size = new System.Drawing.Size(351, 23);
            this.progressBar1.Step = 1;
            this.progressBar1.TabIndex = 6;
            // 
            // SavingTrg_lbl
            // 
            this.SavingTrg_lbl.AutoSize = true;
            this.SavingTrg_lbl.Font = new System.Drawing.Font("Microsoft YaHei UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SavingTrg_lbl.ForeColor = System.Drawing.Color.Gray;
            this.SavingTrg_lbl.Location = new System.Drawing.Point(264, 9);
            this.SavingTrg_lbl.Name = "SavingTrg_lbl";
            this.SavingTrg_lbl.Size = new System.Drawing.Size(55, 17);
            this.SavingTrg_lbl.TabIndex = 6;
            this.SavingTrg_lbl.Text = "Target: ";
            this.SavingTrg_lbl.Click += new System.EventHandler(this.label3_Click);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft YaHei UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(116)))), ((int)(((byte)(86)))), ((int)(((byte)(174)))));
            this.label6.Location = new System.Drawing.Point(2, 2);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(154, 26);
            this.label6.TabIndex = 4;
            this.label6.Text = "Savings Target";
            this.label6.Click += new System.EventHandler(this.label6_Click);
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.White;
            this.panel2.Controls.Add(this.lbl_SubscriptionManager);
            this.panel2.Controls.Add(this.button5);
            this.panel2.Controls.Add(this.button3);
            this.panel2.Controls.Add(this.button4);
            this.panel2.Location = new System.Drawing.Point(16, 137);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(377, 71);
            this.panel2.TabIndex = 7;
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.White;
            this.panel3.Controls.Add(this.lbl_TransactionManager);
            this.panel3.Controls.Add(this.add_button);
            this.panel3.Controls.Add(this.button2);
            this.panel3.Controls.Add(this.button1);
            this.panel3.Location = new System.Drawing.Point(16, 51);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(377, 71);
            this.panel3.TabIndex = 8;
            // 
            // TrList_btn
            // 
            this.TrList_btn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(116)))), ((int)(((byte)(86)))), ((int)(((byte)(174)))));
            this.TrList_btn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.TrList_btn.FlatAppearance.BorderSize = 0;
            this.TrList_btn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.TrList_btn.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TrList_btn.ForeColor = System.Drawing.Color.White;
            this.TrList_btn.Location = new System.Drawing.Point(16, 13);
            this.TrList_btn.Name = "TrList_btn";
            this.TrList_btn.Size = new System.Drawing.Size(185, 32);
            this.TrList_btn.TabIndex = 9;
            this.TrList_btn.Text = "Show Transactions List";
            this.TrList_btn.UseVisualStyleBackColor = false;
            this.TrList_btn.Click += new System.EventHandler(this.TrList_btn_Click);
            // 
            // SbList_btn
            // 
            this.SbList_btn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(116)))), ((int)(((byte)(86)))), ((int)(((byte)(174)))));
            this.SbList_btn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.SbList_btn.FlatAppearance.BorderSize = 0;
            this.SbList_btn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.SbList_btn.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SbList_btn.ForeColor = System.Drawing.Color.White;
            this.SbList_btn.Location = new System.Drawing.Point(208, 13);
            this.SbList_btn.Name = "SbList_btn";
            this.SbList_btn.Size = new System.Drawing.Size(185, 32);
            this.SbList_btn.TabIndex = 9;
            this.SbList_btn.Text = "Show Subscriptions List";
            this.SbList_btn.UseVisualStyleBackColor = false;
            this.SbList_btn.Click += new System.EventHandler(this.SbList_btn_Click);
            // 
            // Transactions_Control
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Control;
            this.Controls.Add(this.SbList_btn);
            this.Controls.Add(this.TrList_btn);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.ExpensesPanel);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.IncomePanel);
            this.Controls.Add(this.dataGridTransactions);
            this.Name = "Transactions_Control";
            this.Size = new System.Drawing.Size(1017, 430);
            this.Load += new System.EventHandler(this.Transactions_Control_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridTransactions)).EndInit();
            this.IncomePanel.ResumeLayout(false);
            this.IncomePanel.PerformLayout();
            this.ExpensesPanel.ResumeLayout(false);
            this.ExpensesPanel.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.Button add_button;
        public System.Windows.Forms.DataGridView dataGridTransactions;
        private System.Windows.Forms.Label lbl_TransactionManager;
        private System.Windows.Forms.Panel IncomePanel;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel ExpensesPanel;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label totalInc_label;
        private System.Windows.Forms.ProgressBar IncomePgBar;
        private System.Windows.Forms.ProgressBar ExpensesPgBar;
        private System.Windows.Forms.Label totalExp_label;
        private System.Windows.Forms.Label lbl_SubscriptionManager;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.ProgressBar progressBar1;
        private System.Windows.Forms.Label SavingTrg_lbl;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Button TrList_btn;
        private System.Windows.Forms.Button SbList_btn;
        private System.Windows.Forms.Label incomeTarget_lbl;
        private System.Windows.Forms.Label spendingTrg_lbl;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
    }
}
