﻿using System;
using System.Data;
using System.Windows.Forms;
using Atestat.Budgets;
using Atestat.Repos;
using Atestat.Transactions;

namespace Atestat.Controls
{
    public partial class Budget_Control: UserControl
    {
        public BudgetsDataGrid budgetsDataGrid = new BudgetsDataGrid();
        public BudgetWizard budgetWizard = new BudgetWizard();
        public BudgetTemplateWizard budgetTemplateWizard = new BudgetTemplateWizard();

        public Budget_Control()
        {
            InitializeComponent();
        }

        private void Budget_Control_Load(object sender, EventArgs e)
        {
            panel_multi_function.Controls.Clear();
            panel_multi_function.Controls.Add(budgetsDataGrid);
            budgetsDataGrid.Dock = DockStyle.Fill;

            label6.Text = TransactionRepository.Instance.LoadAlrets();
            LoadProgressBars();
        }

        // Add budget button
        private void button1_Click(object sender, EventArgs e)
        {
            panel_multi_function.Controls.Clear();
            panel_multi_function.Controls.Add(budgetWizard);
            budgetWizard.Dock = DockStyle.Fill;
        }

        // Edit budget button
        private void button2_Click(object sender, EventArgs e)
        {
            if(panel_multi_function.Controls.Contains(budgetsDataGrid) == false)
            {
                MessageBox.Show("Please select a budget to edit.");
                return;
            }
            else
            {
                DataGridViewRow selectedRow = budgetsDataGrid.dataGridBudgets.SelectedRows[0];
                EditBudgetWizard editBudgetWizard = new EditBudgetWizard(selectedRow);

                panel_multi_function.Controls.Clear();
                panel_multi_function.Controls.Add(editBudgetWizard);
                editBudgetWizard.Dock = DockStyle.Fill;
            }
        }

        // View Budgets button
        private void button4_Click(object sender, EventArgs e)
        {
            panel_multi_function.Controls.Clear();
            panel_multi_function.Controls.Add(budgetsDataGrid);
            budgetsDataGrid.Dock = DockStyle.Fill;
            budgetsDataGrid.LoadData();
        }

        private void panel_BudgetsCalendar_Paint(object sender, PaintEventArgs e)
        {
            
        }

        private void button5_Click(object sender, EventArgs e)
        {
            if (comboBox2.SelectedIndex != -1 && comboBox3.SelectedIndex != -1)
            {
                BudgetsCalendarInfo budgetsCalendarInfo = new BudgetsCalendarInfo(comboBox2.SelectedItem.ToString(), comboBox3.SelectedItem.ToString());

                panel_multi_function.Controls.Clear();
                panel_multi_function.Controls.Add(budgetsCalendarInfo);
                budgetsCalendarInfo.Dock = DockStyle.Fill;
            }
        }

        private void button6_Click(object sender, EventArgs e)
        {
            if (panel_multi_function.Controls.Contains(budgetsDataGrid) == false)
            {
                MessageBox.Show("Please select a budget to delete.");
                return;
            }
            else
            {
                DataGridViewRow selectedRow = budgetsDataGrid.dataGridBudgets.SelectedRows[0];

                // Asking if you're sure about the deletion
                if (MessageBox.Show("Are you sure you want to delete this budget?",
                        "Confirm Deletion",
                        MessageBoxButtons.YesNo,
                        MessageBoxIcon.Question) == DialogResult.Yes)
                {
                    BudgetsRepository.Instance.DeleteBudget(selectedRow);
                    budgetsDataGrid.LoadData();
                }
            }
        }

        public void LoadProgressBars()
        {
            ProgressBars_Repository.Instance.LoadValues();

            circularProgressBar1.Value = ProgressBars_Repository.Instance.LoadIncomeBars();
            circularProgressBar2.Value = ProgressBars_Repository.Instance.LoadExpenseBar();

            label9.Text = ProgressBars_Repository.Instance.LoadIncomeBars().ToString() + "%";
            label11.Text = ProgressBars_Repository.Instance.LoadExpenseBar().ToString() + "%";
        }

        //Templates Button
        private void button3_Click(object sender, EventArgs e)
        {
            panel_multi_function.Controls.Clear();
            panel_multi_function.Controls.Add(budgetTemplateWizard);
            budgetTemplateWizard.Dock = DockStyle.Fill;
        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void circularProgressBar1_Click(object sender, EventArgs e)
        {

        }

        private void button7_Click(object sender, EventArgs e)
        {
            using (SaveFileDialog saveFileDialog = new SaveFileDialog())
            {
                saveFileDialog.Filter = "PDF files (*.pdf)|*.pdf";
                saveFileDialog.Title = "Save report as PDF";

                // Show the dialog.
                if (saveFileDialog.ShowDialog() == DialogResult.OK)
                {
                    try
                    {
                        // Path chosen by user
                        string pdfPath = saveFileDialog.FileName;

                        // Call the PDF creation logic (examples with MigraDoc or iTextSharp)
                        ReportsRepository.Instance.CreatePdfFromData(TransactionRepository.Instance.GetMonthlySpending(comboBox2.Text), pdfPath);

                        // Notify user
                        MessageBox.Show("PDF generated successfully!");

                        // Optional: open PDF automatically
                        // System.Diagnostics.Process.Start(pdfPath);
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Error generating PDF: " + ex.Message);
                    }
                }
            }
        }
    }
}
