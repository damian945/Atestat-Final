﻿using System;
using System.Windows.Forms;
using System.Windows.Forms.DataVisualization.Charting;

namespace Atestat
{
    public partial class Dashboard: Form
    {
        Controls.Dashboard_Control dashboardControl = new Controls.Dashboard_Control();
        Controls.Transactions_Control transactionsControl = new Controls.Transactions_Control();
        Controls.Budget_Control budgetControl = new Controls.Budget_Control();

        public Dashboard()
        {
            InitializeComponent();
        }

        private void Dashboard_Load(object sender, EventArgs e)
        {
            panelMain.Controls.Clear();
            panelMain.Controls.Add(dashboardControl);
            dashboardControl.Dock = DockStyle.Fill;
        }

        // Go to Home tab
        private void home_button_Click(object sender, EventArgs e)
        {
            panelMain.Controls.Clear();
            panelMain.Controls.Add(dashboardControl);
            dashboardControl.Dock = DockStyle.Fill;
        }

        // Go to Transactions tab
        private void transactions_button_Click(object sender, EventArgs e)
        {
            panelMain.Controls.Clear();
            panelMain.Controls.Add(transactionsControl);
            dashboardControl.Dock = DockStyle.Fill;
        }

        // Go to Budget tab
        private void budget_button_Click(object sender, EventArgs e)
        {
            panelMain.Controls.Clear();
            panelMain.Controls.Add(budgetControl);
            dashboardControl.Dock = DockStyle.Fill;
        }

        private void panelMain_Paint(object sender, PaintEventArgs e)
        {

        }
    }
}
