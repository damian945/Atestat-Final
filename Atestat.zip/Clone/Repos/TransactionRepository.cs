﻿using System;
using System.Data;
using System.Data.OleDb;
using System.Data.SqlClient;
using System.Globalization;
using System.Text;
using System.Windows.Forms;
using Atestat.Manager;
using Atestat.Models;

namespace Atestat.Transactions
{
    class TransactionRepository
    {
        // Singleton pattern to ensure only one instance of TransactionRepository exists
        private static readonly Lazy<TransactionRepository> lazy =
            new Lazy<TransactionRepository>(() => new TransactionRepository());

        public static TransactionRepository Instance
        {
            get { return lazy.Value; }
        }

        private TransactionRepository() { }




        private string connectionString =
            @"Provider=Microsoft.Jet.OLEDB.4.0;Data Source=|DataDirectory|\db_transactions.mdb;
  Persist Security Info=False;"; 

        // Sync the categories
        public DataTable GetCategories()
        {
            var dt = new DataTable();

            string sql = "SELECT CategoryID, CategoryName FROM db_categories";

            using (var conn = new OleDbConnection(connectionString))
            {
                conn.Open();
                using (var cmd = new OleDbCommand(sql, conn))
                {
                    using (var adapter = new OleDbDataAdapter(cmd))
                    {
                        adapter.Fill(dt);
                    }
                }
            }

            return dt;
        }

        public void InsertTransaction(TransactionModel transaction)
        {
            string sql = @"
                INSERT INTO db_transactions 
                    ([DateOfTransaction], [TransactionType], [CategoryID], [Amount], [Note])
                VALUES
                    (@DateOfTransaction, @TransactionType, @CategoryID, @Amount, @Note)";

            using (var conn = new OleDbConnection(connectionString))
            {
                conn.Open();
                using (var cmd = new OleDbCommand(sql, conn))
                {
                    // Make sure you add parameters in the same order 
                    // they appear in the VALUES(...) clause:
                    cmd.Parameters.Add("@DateOfTransaction", OleDbType.Date).Value = transaction.DateOfTransaction;
                    cmd.Parameters.Add("@TransactionType", OleDbType.VarChar, 50).Value = transaction.TransactionType;
                    cmd.Parameters.Add("@CategoryID", OleDbType.Integer).Value = transaction.CategoryID;
                    cmd.Parameters.Add("@Amount", OleDbType.Double).Value = Convert.ToDouble(transaction.Amount);
                    cmd.Parameters.Add("@Note", OleDbType.VarChar, 255).Value = string.IsNullOrEmpty(transaction.Note) ? (object)DBNull.Value : transaction.Note;


                    cmd.ExecuteNonQuery();
                }
            }
        }

        public void EditTransaction(TransactionModel newTransaction, int transactionID)
        {
            string edit = "UPDATE [db_transactions] " +
                "SET [DateOfTransaction] = @NewDate, [TransactionType] = @NewType, " +
                "[CategoryID] = @NewCategory, [Amount] = @NewAmount, [Note] = @NewNote " +
                "WHERE [TransactionID] = @id";

            using (var conn = new OleDbConnection(connectionString))
            {
                conn.Open();
                using (var cmd = new OleDbCommand(edit, conn))
                {
                    cmd.Parameters.Add("@NewDate", OleDbType.Date).Value = newTransaction.DateOfTransaction;
                    cmd.Parameters.Add("@NewType", OleDbType.VarChar, 50).Value = newTransaction.TransactionType;
                    cmd.Parameters.Add("@NewCategory", OleDbType.Integer).Value = newTransaction.CategoryID;
                    cmd.Parameters.Add("@NewAmount", OleDbType.Double).Value = Convert.ToDouble(newTransaction.Amount);
                    cmd.Parameters.Add("@NewNote", OleDbType.VarChar, 255).Value = string.IsNullOrEmpty(newTransaction.Note) ? (object)DBNull.Value : newTransaction.Note;

                    cmd.Parameters.Add("@id", OleDbType.Integer).Value = transactionID;

                    int rowsAffected = cmd.ExecuteNonQuery();

                    if (rowsAffected == 0)
                    {
                        MessageBox.Show("Update failed: No matching record was found.",
                                        "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
        }

        public void DeleteTransaction(DataGridViewRow selectedRow)
        {
            int transactionID = Convert.ToInt32(selectedRow.Cells["ID"].Value);

            string del = "DELETE FROM [db_transactions] " +
                 "WHERE [TransactionID] = @id ";

            using (var conn = new OleDbConnection(connectionString))
            {
                conn.Open();
                using (var cmd = new OleDbCommand(del, conn))
                {
                    cmd.Parameters.Add("@id", OleDbType.Integer).Value = transactionID;

                    int rowsAffected = cmd.ExecuteNonQuery();

                    // Check if a record was actually deleted
                    if (rowsAffected == 0)
                    {
                        throw new Exception("No record found with the specified TransactionID");
                    }
                }
            }
        }

        public DataTable LoadTransactions()
        {
            string load = "SELECT " +
                "t.TransactionID as [ID], t.DateOfTransaction as [Date]," +
                "t.TransactionType as [Type]," +
                "c.CategoryName as [Category]," +
                "t.Amount as [Amount]," +
                "t.Note as [Notes] " +
                "FROM [db_transactions] t INNER JOIN [db_categories] c ON t.CategoryID = c.CategoryID"
                + " ORDER BY t.DateOfTransaction DESC, t.Amount DESC";

            DataTable dt = new DataTable();

            try
            {
                using (OleDbConnection conn = new OleDbConnection(connectionString))
                {
                    conn.Open();
                    using (OleDbCommand cmd = new OleDbCommand(load, conn))
                    {
                        using (OleDbDataAdapter adapter = new OleDbDataAdapter(cmd))
                        {

                            adapter.Fill(dt);

                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error loading data: " + ex.Message);
            }

            return dt;
        }

        public int GetIncomeValue()
        {
            string query = "SELECT SUM(Amount) FROM [db_transactions] WHERE TransactionType = 'Income'";

            using (OleDbConnection conn = new OleDbConnection(connectionString))
            {
                conn.Open();
                using (OleDbCommand command = new OleDbCommand(query, conn))
                {
                    object result = command.ExecuteScalar();

                    if (result != null && result != DBNull.Value)
                    {
                        return Convert.ToInt32(result);
                    }
                    else
                    {
                        return -1; // Return 0 if there are no income records
                        throw new Exception("Null result");
                    }
                }
            }
        }

        public int GetExpensesValue()
        {
            string query = "SELECT SUM(Amount) FROM [db_transactions] WHERE TransactionType = 'Expense'";

            using (OleDbConnection conn = new OleDbConnection(connectionString))
            {
                conn.Open();
                using (OleDbCommand command = new OleDbCommand(query, conn))
                {

                    object result = command.ExecuteScalar();

                    if (result != null && result != DBNull.Value)
                    {
                        return Convert.ToInt32(result);
                    }
                    else
                    {
                        return -1; // Return 0 if there are no income records
                        throw new Exception("Null result");
                    }
                }
            }
        }

        public int GetDailySpending(int day, int month, int year)
        {
            DateTime startOfDay = new DateTime(year, month, day, 0, 0, 0);
            DateTime endOfDay = startOfDay.AddDays(1);

            string query = "SELECT SUM(Amount) FROM [db_transactions] " +
                           "WHERE DateOfTransaction >= @StartOfDay AND DateOfTransaction < @EndOfDay " +
                           "AND TransactionType = 'Expense'";

            using (OleDbConnection conn = new OleDbConnection(connectionString))
            {
                conn.Open();
                using (OleDbCommand command = new OleDbCommand(query, conn))
                {
                    command.Parameters.Add("@StartOfDay", OleDbType.Date).Value = startOfDay;
                    command.Parameters.Add("@EndOfDay", OleDbType.Date).Value = endOfDay;

                    object result = command.ExecuteScalar();

                    if (result != null && result != DBNull.Value)
                    {
                        return Convert.ToInt32(result);
                    }
                    else
                    {
                        return 0; // Return 0 if there are no income records
                    }
                }
            }
        }

        public string LoadAlrets()
        {
            int result_int;

            string query = "SELECT SUM(Amount) FROM [db_transactions] " +
                           "WHERE TransactionType = 'Expense' AND MONTH(DateOfTransaction) = @CurrentMonth";

            using (OleDbConnection conn = new OleDbConnection(connectionString))
            {
                conn.Open();
                using (OleDbCommand command = new OleDbCommand(query, conn))
                {
                    command.Parameters.Add("@CurrentMonth", OleDbType.VarChar, 10).Value = DateTime.Now.ToString("MMMM");

                    object result = command.ExecuteScalar();

                    if (result != null && result != DBNull.Value)
                    {
                        result_int = Convert.ToInt32(result);
                    }
                    else
                    {
                        return "As of today, you have no alerts!";
                    }
                }
            }

            if (result_int < BudgetManager.Instance.CurrentBudget.SpendingLimit * 0.75)
            {
                return "As of today, you have no alerts!";
            }
            else
            {
                return "You have spent " + result_int + " out of " + BudgetManager.Instance.CurrentBudget.SpendingLimit +
                       " this month. You are nearing your spending limit!";
            }


        }

        public DataTable GetMonthlySpending(string month)
        {
            int monthNumber = DateTime.ParseExact(month, "MMMM", CultureInfo.InvariantCulture).Month;


            string load = "SELECT " +
                "t.DateOfTransaction as [Date]," +
                "t.TransactionType as [Type]," +
                "c.CategoryName as [Category]," +
                "t.Amount as [Amount] " +
                "FROM [db_transactions] t INNER JOIN [db_categories] c ON t.CategoryID = c.CategoryID " +
                "WHERE MONTH(DateOfTransaction) = @ChoosenMonth"
                + " ORDER BY t.DateOfTransaction DESC, t.Amount DESC";

            DataTable dt = new DataTable();

            try
            {
                using (OleDbConnection conn = new OleDbConnection(connectionString))
                {
                    conn.Open();
                    using (OleDbCommand cmd = new OleDbCommand(load, conn))
                    {
                        cmd.Parameters.Add("@ChoosenMonth", OleDbType.Integer).Value = monthNumber;

                        using (OleDbDataAdapter adapter = new OleDbDataAdapter(cmd))
                        {

                            adapter.Fill(dt);

                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error loading data: " + ex.Message);
            }

            return dt;
        }

        public DataTable GetMonthlyExpensesByCategory()
        {
            string sql = @"
SELECT 
    c.CategoryName,
    SUM(t.Amount) AS TotalAmount
FROM 
    ([db_transactions] AS t 
     INNER JOIN [db_Categories] AS c 
       ON t.CategoryID = c.CategoryID)
WHERE 
    t.TransactionType = ?                      
    AND t.DateOfTransaction >= ?                
    AND t.DateOfTransaction <  ?                    
GROUP BY 
    c.CategoryName
ORDER BY 
    SUM(t.Amount) DESC;
";
            DataTable dt = new DataTable();
            try
            {
                using (var conn = new OleDbConnection(connectionString))
                using (var cmd = new OleDbCommand(sql, conn))
                {
                    // 1st parameter → TransactionType = 'Expense'
                    cmd.Parameters.AddWithValue("p1", "Expense");

                    // compute month bounds
                    DateTime startOfMonth = new DateTime(DateTime.Today.Year, DateTime.Today.Month, 1);
                    DateTime startOfNextMonth = startOfMonth.AddMonths(1);

                    // 2nd parameter → lower bound
                    cmd.Parameters.AddWithValue("p2", startOfMonth);
                    // 3rd parameter → upper bound
                    cmd.Parameters.AddWithValue("p3", startOfNextMonth);

                    using (var adapter = new OleDbDataAdapter(cmd))
                        adapter.Fill(dt);
                }
            }
            catch (OleDbException ex)
            {
                var sb = new StringBuilder();
                sb.AppendLine("OLEDB Exception:");
                foreach (OleDbError err in ex.Errors)
                    sb.AppendLine($"  Provider: {err.Source}  Code: {err.NativeError}  Msg: {err.Message}");
                MessageBox.Show(sb.ToString(), "Detailed OLEDB Error");
            }

            return dt;
        }

        public DataTable GetLastYearIncomeVsExpensesByMonth()
        {
            // 1) SQL: group by Month(), sum Income vs Expense
            string sql = @"
SELECT 
    Month(DateOfTransaction)    AS [Month],
    SUM(IIF(TransactionType = 'Income',  Amount, 0)) AS TotalIncome,
    SUM(IIF(TransactionType = 'Expense', Amount, 0)) AS TotalExpense
FROM 
    [db_transactions]
WHERE 
    DateOfTransaction >= ?
    AND DateOfTransaction <  ?
GROUP BY 
    Month(DateOfTransaction)
ORDER BY
    Month(DateOfTransaction);";

            // 2) Compute last‐year bounds
            int lastYear = DateTime.Today.Year - 1;
            var startOfLastYear = new DateTime(lastYear, 1, 1);
            var startOfThisYear = new DateTime(lastYear + 1, 1, 1);

            // 3) Fill and return DataTable
            var dt = new DataTable();
            using (var conn = new OleDbConnection(connectionString))
            using (var cmd = new OleDbCommand(sql, conn))
            {
                // positional parameters in order
                cmd.Parameters.AddWithValue("p1", startOfLastYear);
                cmd.Parameters.AddWithValue("p2", startOfThisYear);

                using (var adapter = new OleDbDataAdapter(cmd))
                    adapter.Fill(dt);
            }
            return dt;
        }


    }
}
