﻿using System;
using System.Data;
using System.Data.OleDb;
using System.Windows.Forms;
using Atestat.Models;

namespace Atestat.Repos
{
    class SubscriptionRepository
    {
        // Singleton pattern
        private static readonly Lazy<SubscriptionRepository> lazy =
            new Lazy<SubscriptionRepository>(() => new SubscriptionRepository());

        public static SubscriptionRepository Instance
        {
            get { return lazy.Value; }
        }
        private SubscriptionRepository() { }

        private string connectionString =
             @"Provider=Microsoft.Jet.OLEDB.4.0;Data Source=|DataDirectory|\db_transactions.mdb;Persist Security Info=False;";

        public DataTable LoadSubscriptions()
        {
            string load = "SELECT " +
                "[SubscriptionID] as [ID], " +
                "[SubscriptionName] as [Name]," +
                "[MonthlyCost]," +
                "[EndDate], " + 
                "[Status] " +
                "FROM [db_subscriptions] ORDER BY [SubscriptionID]";

            DataTable dt = new DataTable();

            try
            {
                using (OleDbConnection conn = new OleDbConnection(connectionString))
                {
                    conn.Open();
                    using (OleDbCommand cmd = new OleDbCommand(load, conn))
                    {
                        using (OleDbDataAdapter adapter = new OleDbDataAdapter(cmd))
                        {

                            adapter.Fill(dt);

                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error loading data: " + ex.Message);
            }

            return dt;
        }

        public void InsertSubscription(SubscriptionModel subscriptionModel)
        {
            string insert = "INSERT INTO db_subscriptions " +
                "([SubscriptionName],[MonthlyCost],[EndDate],[Status]) " +
                "VALUES " +
                "(@SubscriptionName, @MonthlyCost, @EndDate, @Status)";

            using (var conn = new OleDbConnection(connectionString))
            {
                conn.Open();
                using (var cmd = new OleDbCommand(insert, conn))
                {
                    cmd.Parameters.Add("@SubscriptionName", OleDbType.VarChar, 50).Value = subscriptionModel.SubscriptionName;
                    cmd.Parameters.Add("@MonthlyCost", OleDbType.Double).Value = subscriptionModel.MonthlyCost;
                    cmd.Parameters.Add("@EndDate", OleDbType.Date).Value = subscriptionModel.EndDate;
                    cmd.Parameters.Add("@Status", OleDbType.VarChar, 10).Value = subscriptionModel.Status;

                    cmd.ExecuteNonQuery();
                }
            }
        }

        public void DeleteSubscription(DataGridViewRow selectedRow)
        {
            int subscriptionID = Convert.ToInt32(selectedRow.Cells["ID"].Value);

            string del = "DELETE FROM [db_subscriptions] " +
                 "WHERE [SubscriptionID] = @id ";

            using (var conn = new OleDbConnection(connectionString))
            {
                conn.Open();
                using (var cmd = new OleDbCommand(del, conn))
                {
                    cmd.Parameters.Add("@id", OleDbType.Integer).Value = subscriptionID;

                    int rowsAffected = cmd.ExecuteNonQuery();

                    // Check if a record was actually deleted
                    if (rowsAffected == 0)
                    {
                        throw new Exception("No record found with the specified TransactionID");
                    }
                }
            }
        }

        public void EditSubscription(SubscriptionModel newSubscription, int subscriptionID)
        {
            string edit = "UPDATE [db_subscriptions] " +
                "SET [SubscriptionName] = @NewName, [MonthlyCost] = @NewCost, " +
                "[EndDate] = @NewDate, [Status] = @NewStatus " +
                "WHERE [SubscriptionID] = @id";

            using (var conn = new OleDbConnection(connectionString))
            {
                conn.Open();
                using (var cmd = new OleDbCommand(edit, conn))
                {
                    cmd.Parameters.Add("@NewName", OleDbType.VarChar, 50).Value = newSubscription.SubscriptionName;
                    cmd.Parameters.Add("@NewCost", OleDbType.Double).Value = newSubscription.MonthlyCost;
                    cmd.Parameters.Add("@NewDate", OleDbType.Date).Value = newSubscription.EndDate;
                    cmd.Parameters.Add("@NewStatus", OleDbType.VarChar, 10).Value = newSubscription.Status;

                    cmd.Parameters.Add("@id", OleDbType.Integer).Value = subscriptionID;

                    int rowsAffected = cmd.ExecuteNonQuery();

                    if (rowsAffected == 0)
                    {
                        MessageBox.Show("Update failed: No matching record was found.",
                                        "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
        }
    
        public int GetSubscriptionsValue()
        {
            string query = "SELECT SUM(MonthlyCost) FROM [db_subscriptions] WHERE Status = 'Active'";

            using (OleDbConnection conn = new OleDbConnection(connectionString))
            {
                conn.Open();
                using (OleDbCommand command = new OleDbCommand(query, conn))
                {
                    object result = command.ExecuteScalar();

                    if (result != null && result != DBNull.Value)
                    {
                        return Convert.ToInt32(result);
                    }
                    else
                    {
                        return -1; // Return 0 if there are no income records
                        throw new Exception("Null result");
                    }
                }
            }
        }
    }
}
