﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.OleDb;
using System.Security.Cryptography.X509Certificates;
using System.Windows.Forms;
using Atestat.Models;

namespace Atestat.Repos
{
    class BudgetsRepository
    {
        private static readonly Lazy<BudgetsRepository> lazy = new Lazy<BudgetsRepository>(() => new BudgetsRepository());

        public static BudgetsRepository Instance
        {
            get { return lazy.Value; }
        }
        private BudgetsRepository() { }

        private string connectionString =
             @"Provider=Microsoft.Jet.OLEDB.4.0;Data Source=|DataDirectory|\db_transactions.mdb;Persist Security Info=False;";

        public DataTable LoadBudgets()
        {
            string load = "SELECT " +
                "[BudgetID] as [ID], " +
                "[BudgetMonth] as [Month]," +
                "[BudgetYear] as [Year]," +
                "[IncomeTarget]," +
                "[SpendingLimit]," +
                "SavingsTarget " +
                "FROM [db_budgets] ";

            DataTable dt = new DataTable();

            try
            {
                using (OleDbConnection conn = new OleDbConnection(connectionString))
                {
                    conn.Open();
                    using (OleDbCommand cmd = new OleDbCommand(load, conn))
                    {
                        using (OleDbDataAdapter adapter = new OleDbDataAdapter(cmd))
                        {

                            adapter.Fill(dt);

                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error loading data: " + ex.Message);
            }

            return dt;
        }

        public void InsertBudget(BudgetModel budget)
        {
            string sql = @"
                INSERT INTO db_budgets 
                    ([BudgetMonth], [BudgetYear], [IncomeTarget], [SpendingLimit], [SavingsTarget])
                VALUES
                    (@BudgetMonth, @BudgetYear, @IncomeTarget, @SpendingLimit, @SavingsTarget)";

            using (var conn = new OleDbConnection(connectionString))
            {
                conn.Open();
                using (var cmd = new OleDbCommand(sql, conn))
                {
                    cmd.Parameters.Add("@BudgetMonth", OleDbType.VarChar, 20).Value = budget.BudgetMonth;
                    cmd.Parameters.Add("@BudgetYear", OleDbType.VarChar, 20).Value = budget.BudgetYear;
                    cmd.Parameters.Add("@IncomeTarget", OleDbType.Double).Value = budget.IncomeTarget;
                    cmd.Parameters.Add("@SpendingLimit", OleDbType.Double).Value = budget.SpendingLimit;
                    cmd.Parameters.Add("@SavingsTarget", OleDbType.Double).Value = budget.SavingsTarget;


                    cmd.ExecuteNonQuery();
                }
            }
        }

        public void EditBudget(BudgetModel newBudget, int budgetID)
        {
            string edit = "UPDATE [db_budgets] " +
                "SET [BudgetMonth] = @NewMonth, [BudgetYear] = @NewYear, " +
                "[IncomeTarget] = @NewIncomeTarget, [SpendingLimit] = @NewSpendingLimit, [SavingsTarget] = @NewSavingsTarget " +
                "WHERE [BudgetID] = @id";

            using (var conn = new OleDbConnection(connectionString))
            {
                conn.Open();
                using (var cmd = new OleDbCommand(edit, conn))
                {
                    cmd.Parameters.Add("@NewMonth", OleDbType.VarChar, 20).Value = newBudget.BudgetMonth;
                    cmd.Parameters.Add("@NewYear", OleDbType.VarChar, 20).Value = newBudget.BudgetYear;
                    cmd.Parameters.Add("@NewIncomeTarget", OleDbType.Double).Value = newBudget.IncomeTarget;
                    cmd.Parameters.Add("@NewSpendingLimit", OleDbType.Double).Value = newBudget.SpendingLimit;
                    cmd.Parameters.Add("@NewSavingsTarget", OleDbType.Double).Value = newBudget.SavingsTarget;

                    cmd.Parameters.Add("@id", OleDbType.Integer).Value = budgetID;

                    int rowsAffected = cmd.ExecuteNonQuery();

                    if (rowsAffected == 0)
                    {
                        MessageBox.Show("Update failed: No matching record was found.",
                                        "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
        }

        public void DeleteBudget(DataGridViewRow selectedRow)
        {
            int budgetID = Convert.ToInt32(selectedRow.Cells["ID"].Value);

            string delete = "DELETE FROM [db_budgets] WHERE [BudgetID] = @id";
            using (var conn = new OleDbConnection(connectionString))
            {
                conn.Open();
                using (var cmd = new OleDbCommand(delete, conn))
                {
                    cmd.Parameters.Add("@id", OleDbType.Integer).Value = budgetID; // Replace with the actual ID to delete
                    int rowsAffected = cmd.ExecuteNonQuery();
                    if (rowsAffected == 0)
                    {
                        MessageBox.Show("Delete failed: No matching record was found.",
                                        "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
        }

        public DataTable LoadSpecificBudget(string month, string year)
        {
            string load = "SELECT " +
                "[IncomeTarget]," +
                "[SpendingLimit]," +
                "SavingsTarget " +
                "FROM [db_budgets] " +
                "WHERE [BudgetMonth] = @Month AND [BudgetYear] = @Year";

            DataTable dt = new DataTable();

            try
            {
                using (OleDbConnection conn = new OleDbConnection(connectionString))
                {
                    conn.Open();
                    using (OleDbCommand cmd = new OleDbCommand(load, conn))
                    {
                        cmd.Parameters.Add("@Month", OleDbType.VarChar, 20).Value = month;
                        cmd.Parameters.Add("@Year", OleDbType.VarChar, 20).Value = year;

                        using (OleDbDataAdapter adapter = new OleDbDataAdapter(cmd))
                        {

                            adapter.Fill(dt);

                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error loading data: " + ex.Message);
            }

            if (dt == null || dt.Rows.Count == 0)
            {
                return LoadDefBudget();
            }
            else
            {
                return dt;
            }

        }

        public DataTable LoadDefBudget()
        {
            string query = "SELECT [IncomeTarget], [SpendingLimit], [SavingsTarget] FROM [db_defaultBudget]";
            DataTable dt = new DataTable();

            try
            {
                using (OleDbConnection conn = new OleDbConnection(connectionString))
                {
                    conn.Open();
                    using (OleDbCommand command = new OleDbCommand(query, conn))
                    {
                        using (OleDbDataAdapter adapter = new OleDbDataAdapter(command))
                        {
                            adapter.Fill(dt);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error loading default budget: " + ex.Message);
            }

            return dt;
        }

        public DataTable LoadTemplates()
        {
            string load = "SELECT " +
                "[TemplateName] as [Name], " +
                "[IncomeTarget]," +
                "[SpendingLimit]," +
                "[SavingsTarget] " +
                "FROM [db_budgetTemplates]";

            DataTable dt = new DataTable();

            try
            {
                using (OleDbConnection conn = new OleDbConnection(connectionString))
                {
                    conn.Open();
                    using (OleDbCommand cmd = new OleDbCommand(load, conn))
                    {
                        using (OleDbDataAdapter adapter = new OleDbDataAdapter(cmd))
                        {

                            adapter.Fill(dt);

                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error loading data: " + ex.Message);
            }

            return dt;
        }

        public void InsertTemplate(BudgetModel budget, string templateName)
        {
            string sql = @"
                INSERT INTO db_budgetTemplates 
                    ([TemplateName], [IncomeTarget], [SpendingLimit], [SavingsTarget])
                VALUES
                    (@TemplateName, @IncomeTarget, @SpendingLimit, @SavingsTarget)";
            using (var conn = new OleDbConnection(connectionString))
            {
                conn.Open();
                using (var cmd = new OleDbCommand(sql, conn))
                {
                    cmd.Parameters.Add("@TemplateName", OleDbType.VarChar, 20).Value = templateName;
                    cmd.Parameters.Add("@IncomeTarget", OleDbType.Double).Value = budget.IncomeTarget;
                    cmd.Parameters.Add("@SpendingLimit", OleDbType.Double).Value = budget.SpendingLimit;
                    cmd.Parameters.Add("@SavingsTarget", OleDbType.Double).Value = budget.SavingsTarget;

                    cmd.ExecuteNonQuery();
                }
            }
        }

        public void EditTemplate(BudgetModel newBudget, string newTemplateName, string oldTemplateName) 
        {
            string edit = "UPDATE [db_budgetTemplates] " +
                "SET [TemplateName] = @NewName, " +
                "[IncomeTarget] = @NewIncomeTarget, [SpendingLimit] = @NewSpendingLimit, [SavingsTarget] = @NewSavingsTarget " +
                "WHERE [TemplateName] = @templateName";

            using (var conn = new OleDbConnection(connectionString))
            {
                conn.Open();
                using (var cmd = new OleDbCommand(edit, conn))
                {
                    cmd.Parameters.Add("@NewName", OleDbType.VarChar, 20).Value = newTemplateName;
                    cmd.Parameters.Add("@IncomeTarget", OleDbType.Double).Value = newBudget.IncomeTarget;
                    cmd.Parameters.Add("@SpendingLimit", OleDbType.Double).Value = newBudget.SpendingLimit;
                    cmd.Parameters.Add("@SavingsTarget", OleDbType.Double).Value = newBudget.SavingsTarget;

                    cmd.Parameters.Add("@templateName", OleDbType.VarChar,20).Value = oldTemplateName;

                    int rowsAffected = cmd.ExecuteNonQuery();

                    if (rowsAffected == 0)
                    {
                        MessageBox.Show("Update failed: No matching record was found.",
                                        "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
        }

        public void DeleteTemplate(DataGridViewRow selectedRow)
        {
            string templateName = selectedRow.Cells["Name"].Value.ToString();
            string delete = "DELETE FROM [db_budgetTemplates] WHERE [TemplateName] = @templateName";

            using (var conn = new OleDbConnection(connectionString))
            {
                conn.Open();
                using (var cmd = new OleDbCommand(delete, conn))
                {
                    cmd.Parameters.Add("@templateName", OleDbType.VarChar, 20).Value = templateName;
                    int rowsAffected = cmd.ExecuteNonQuery();
                    if (rowsAffected == 0)
                    {
                        MessageBox.Show("Delete failed: No matching record was found.",
                                        "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
        }
    
    }
}
