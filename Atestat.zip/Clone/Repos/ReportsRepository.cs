﻿using System;
using MigraDoc.DocumentObjectModel;
using MigraDoc.DocumentObjectModel.Tables;
using MigraDoc.DocumentObjectModel.Shapes;
using MigraDoc.Rendering;
using System.Data;

namespace Atestat.Repos
{
    class ReportsRepository
    {
        private static readonly Lazy<ReportsRepository> lazy = new Lazy<ReportsRepository>(() => new ReportsRepository());

        public static ReportsRepository Instance
        {
            get { return lazy.Value; }
        }
        private ReportsRepository() { }

        public void CreatePdfFromData(DataTable dataTable, string pdfPath)
        {
            // 1. Create a new MigraDoc document and add a section
            Document document = new Document();
            Section section = document.AddSection();

            // 2. Add a title to the document
            Paragraph title = section.AddParagraph("DataTable Report");
            title.Format.Font.Size = 16;
            title.Format.Font.Bold = true;
            title.Format.Alignment = ParagraphAlignment.Center;
            title.Format.SpaceAfter = "1cm";

            // 3. Create a table with borders
            Table table = section.AddTable();
            table.Borders.Width = 0.5;
            table.Borders.Color = Colors.Black;

            // 4. Define columns to match DataTable columns (fixed width per column)
            foreach (DataColumn column in dataTable.Columns)
            {
                table.AddColumn(Unit.FromCentimeter(4));
            }

            // 5. Create and format the header row
            Row headerRow = table.AddRow();
            headerRow.Shading.Color = Colors.LightGray;
            headerRow.HeadingFormat = true;

            for (int i = 0; i < dataTable.Columns.Count; i++)
            {
                // Add column header text
                Paragraph headerParagraph = headerRow.Cells[i].AddParagraph(dataTable.Columns[i].ColumnName);
                // Center align the header text horizontally and vertically
                headerParagraph.Format.Alignment = ParagraphAlignment.Center;
                headerRow.Cells[i].VerticalAlignment = VerticalAlignment.Center;
                headerRow.Cells[i].Format.Font.Bold = true;
            }

            // 6. Populate the table rows with DataTable content
            foreach (DataRow dataRow in dataTable.Rows)
            {
                Row row = table.AddRow();
                for (int colIndex = 0; colIndex < dataTable.Columns.Count; colIndex++)
                {
                    object cellData = dataRow[colIndex];
                    string cellText = string.Empty;

                    // For the first column, format the data as a date without the time, if applicable.
                    if (colIndex == 0 && dataTable.Columns[colIndex].DataType == typeof(DateTime))
                    {
                        DateTime dt = (DateTime)cellData;
                        cellText = dt.ToShortDateString(); // e.g., "4/9/2025"
                    }
                    else
                    {
                        cellText = cellData?.ToString() ?? string.Empty;
                    }

                    // Add the text to the cell and format it to be centered both horizontally and vertically.
                    Paragraph p = row.Cells[colIndex].AddParagraph(cellText);
                    p.Format.Alignment = ParagraphAlignment.Center;
                    row.Cells[colIndex].VerticalAlignment = VerticalAlignment.Center;
                }
            }

            // 7. (Optional) Add a summary paragraph at the end, center aligned
            Paragraph summary = section.AddParagraph("\nEnd of report.");
            summary.Format.Alignment = ParagraphAlignment.Center;

            // 8. Render the document into a PDF
            PdfDocumentRenderer renderer = new PdfDocumentRenderer();
            renderer.Document = document;
            renderer.RenderDocument();
            renderer.Save(pdfPath);
        }



    }
}
