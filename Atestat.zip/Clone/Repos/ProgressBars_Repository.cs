﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Atestat.Models;
using Atestat.Repos;
using Atestat.Transactions;
using Atestat.Manager;

namespace Atestat.Repos
{
    class ProgressBars_Repository
    {
        // Singleton pattern
        private static readonly Lazy<ProgressBars_Repository> lazy =
            new Lazy<ProgressBars_Repository>(() => new ProgressBars_Repository());

        public static ProgressBars_Repository Instance
        {
            get { return lazy.Value; }
        }

        private ProgressBars_Repository() { }

        public int currentIncome;
        public int currentExpenses;
        public int currentSavings;

        public void LoadValues()
        {
            currentIncome = TransactionRepository.Instance.GetIncomeValue();
            currentExpenses = TransactionRepository.Instance.GetExpensesValue() + SubscriptionRepository.Instance.GetSubscriptionsValue();
            currentSavings = currentIncome - currentExpenses;
        }

        public int LoadIncomeBars()
        {
            // Income Pb
            int incProgressPercentage = (int)((currentIncome / BudgetManager.Instance.CurrentBudget.IncomeTarget) * 100);
            incProgressPercentage = Math.Min(incProgressPercentage, 100);
            return incProgressPercentage;
        }

        public int LoadExpenseBar()
        {
            int expProgressPercentage = (int)((currentExpenses / BudgetManager.Instance.CurrentBudget.SpendingLimit) * 100);
            expProgressPercentage = Math.Min(expProgressPercentage, 100);
            return expProgressPercentage;
        }

        public int LoadSavingsBar()
        {
            int svgProgressPercentage = (int)((currentSavings / BudgetManager.Instance.CurrentBudget.SavingsTarget) * 100);
            svgProgressPercentage = Math.Min(svgProgressPercentage, 100);
            return svgProgressPercentage;
        }

    }
}
