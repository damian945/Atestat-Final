﻿using System;
using System.Windows.Forms;
using Atestat.Models;
using Atestat.Repos;
using Atestat.Controls;

namespace Atestat.Budgets
{
    public partial class BudgetWizard : UserControl
    {
        public BudgetWizard()
        {
            InitializeComponent();
        }

        private void BudgetWizard_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            var budget = new BudgetModel
            {
                BudgetMonth = comboBox1.SelectedItem?.ToString(),
                BudgetYear = comboBox2.SelectedItem?.ToString(),
                IncomeTarget = double.Parse(textBox3.Text),
                SpendingLimit = double.Parse(textBox4.Text),
                SavingsTarget = double.Parse(textBox5.Text)
            };

            BudgetsRepository.Instance.InsertBudget(budget);
            
            this.Controls.Clear();
            this.Controls.Add(new BudgetsDataGrid());
        }
    }
}
