﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Atestat.Models;
using Atestat.Repos;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace Atestat.Budgets
{
    public partial class EditTemplateWizard: UserControl
    {
        private string oldName;

        public event EventHandler RefreshGridRequested;

        public EditTemplateWizard()
        {
            InitializeComponent();
        }

        public EditTemplateWizard(DataGridViewRow selectedRow) : this()
        {
            textBox1.Text = selectedRow.Cells["Name"].Value.ToString();
            oldName = selectedRow.Cells["Name"].Value.ToString();
            textBox3.Text = selectedRow.Cells["IncomeTarget"].Value.ToString();
            textBox4.Text = selectedRow.Cells["SpendingLimit"].Value.ToString();
            textBox5.Text = selectedRow.Cells["SavingsTarget"].Value.ToString();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            var newBudget = new BudgetModel
            {
                IncomeTarget = double.Parse(textBox3.Text),
                SpendingLimit = double.Parse(textBox4.Text),
                SavingsTarget = double.Parse(textBox5.Text)
            };

            BudgetsRepository.Instance.EditTemplate(newBudget, textBox1.Text, oldName);

            RefreshGridRequested?.Invoke(this, EventArgs.Empty);
            this.Controls.Clear();            
        }
    }
}
