﻿using System;
using System.Windows.Forms;
using System.Globalization;
using Atestat.Manager;
using Atestat.Models;
using Atestat.Transactions;
using System.Drawing;
using Atestat.Repos;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace Atestat.Budgets
{
    public partial class BudgetsCalendarInfo : UserControl
    {
        public string choosenMonthStr;
        public string choosenYearStr;

        private int choosenMonth;
        private int choosenYear;
        private int choosenDay;

        private BudgetModel ChoosenBudget;

        public BudgetsCalendarInfo()
        {
            InitializeComponent();
        }

        public BudgetsCalendarInfo(string month, string year) : this()
        {
            choosenMonthStr = month;
            choosenYearStr = year;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            GetBudget();
            if (ValidateDay(textBox4.Text, choosenMonthStr, Int32.Parse(choosenYearStr)))
            {
                label5.Text = label11.Text = ChoosenBudget.SpendingLimit.ToString();
                label12.Text = DailySpendingRec(ChoosenBudget.SpendingLimit).ToString();

                label7.Text = TransactionRepository.Instance.GetDailySpending(choosenDay, choosenMonth, choosenYear).ToString();
            }
            else
            {
                MessageBox.Show("Invalid day. Please enter a valid day for the selected month and year.");
            }
        }

        public bool ValidateDay(string day, string monthStr, int year)
        {

            if (string.IsNullOrEmpty(day) || day.Length != 2 || !int.TryParse(day, out int dayNumber))
            {
                return false;
            }

            foreach (char c in day)
            {
                if (!char.IsDigit(c))
                    return false;
            }

            int month;

            try
            {
                DateTime dt = DateTime.ParseExact(
                    monthStr,
                    new string[] { "MMMM", "MMM" },
                    CultureInfo.InvariantCulture,
                    DateTimeStyles.None);
                month = dt.Month;
            }
            catch
            {
                // If parsing fails, the month string is not valid.
                return false;
            }

            // Determine the maximum days for the given month and year.
            int maxDays = DateTime.DaysInMonth(year, month);

            // Check if the day number is within the valid range for that month.
            if (dayNumber < 1 || dayNumber > maxDays)
            {
                return false;
            }

            choosenMonth = month;
            choosenYear = year;
            choosenDay = dayNumber;
            return true;
        }

        public double DailySpendingRec(double spending)
        {
            return Math.Floor(spending / DateTime.DaysInMonth(choosenYear, choosenMonth));
        }

        public void GetBudget()
        {
            // Pseudo-code: check if custom budget exists for the month.
            ChoosenBudget = BudgetManager.Instance.GetSpecificBudget(choosenMonthStr, choosenYearStr);
            if (ChoosenBudget == null)
            {
                ChoosenBudget = BudgetManager.Instance.GetDefaultBudget();
            }
        }

        private void BudgetsCalendarInfo_Load(object sender, EventArgs e)
        {
            dataGridView1.EnableHeadersVisualStyles = false;

            dataGridView1.ColumnHeadersDefaultCellStyle.BackColor = Color.FromArgb(116, 86, 174);
            dataGridView1.ColumnHeadersDefaultCellStyle.Font = new Font("Nirmala UI", 8, FontStyle.Bold);
            dataGridView1.ColumnHeadersDefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;


            dataGridView1.DataSource = BudgetsRepository.Instance.LoadSpecificBudget(choosenMonthStr, choosenYearStr);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            using (SaveFileDialog saveFileDialog = new SaveFileDialog())
            {
                saveFileDialog.Filter = "PDF files (*.pdf)|*.pdf";
                saveFileDialog.Title = "Save report as PDF";

                // Show the dialog.
                if (saveFileDialog.ShowDialog() == DialogResult.OK)
                {
                    try
                    {
                        // Path chosen by user
                        string pdfPath = saveFileDialog.FileName;

                        // Call the PDF creation logic (examples with MigraDoc or iTextSharp)
                        ReportsRepository.Instance.CreatePdfFromData(TransactionRepository.Instance.GetMonthlySpending(choosenMonthStr), pdfPath);

                        // Notify user
                        MessageBox.Show("PDF generated successfully!");

                        // Optional: open PDF automatically
                        // System.Diagnostics.Process.Start(pdfPath);
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Error generating PDF: " + ex.Message);
                    }
                }
            }
        }
    }
}
