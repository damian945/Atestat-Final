﻿using System;
using System.Windows.Forms;
using Atestat.Models;
using Atestat.Repos;

namespace Atestat.Budgets
{
    public partial class AddTemplateWizard: UserControl
    {
        public event EventHandler RefreshGridRequested;

        public AddTemplateWizard()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            var budget = new BudgetModel
            {
                IncomeTarget = double.Parse(textBox3.Text),
                SpendingLimit = double.Parse(textBox4.Text),
                SavingsTarget = double.Parse(textBox5.Text)
            };

            BudgetsRepository.Instance.InsertTemplate(budget, textBox1.Text);

            RefreshGridRequested?.Invoke(this, EventArgs.Empty);
            this.Controls.Clear();
        }
    }
}
