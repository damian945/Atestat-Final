﻿using System;
using System.Drawing;
using System.Windows.Forms;
using Atestat.Repos;

namespace Atestat.Budgets
{
    public partial class BudgetsDataGrid: UserControl
    {
        public BudgetsDataGrid()
        {
            InitializeComponent();
        }

        private void BudgetsDataGrid_Load(object sender, EventArgs e)
        {
            dataGridBudgets.EnableHeadersVisualStyles = false;

            dataGridBudgets.ColumnHeadersDefaultCellStyle.BackColor = Color.FromArgb(116, 86, 174);
            dataGridBudgets.ColumnHeadersDefaultCellStyle.Font = new Font("Nirmala UI", 8, FontStyle.Bold);
            dataGridBudgets.ColumnHeadersDefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;

            dataGridBudgets.DataSource = BudgetsRepository.Instance.LoadBudgets();
        }

        private void dataGridBudgets_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        public void LoadData()
        {
            dataGridBudgets.DataSource = BudgetsRepository.Instance.LoadBudgets();
        }
    }
}
