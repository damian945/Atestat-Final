﻿using Atestat.Repos;
using System;
using System.Drawing;
using System.Windows.Forms;
using Atestat.Repos;

namespace Atestat.Budgets
{
    public partial class BudgetTemplateWizard : UserControl
    {
        public AddTemplateWizard addTemplateWizard = new AddTemplateWizard();

        public BudgetTemplateWizard()
        {
            InitializeComponent();
        }

        // Add a template
        private void button1_Click(object sender, EventArgs e)
        {

            addTemplateWizard.RefreshGridRequested += (s, args) =>
            {
                RefreshDataGrid();
            };  

            panel1.Controls.Clear();
            panel1.Controls.Add(addTemplateWizard);
            addTemplateWizard.Dock = DockStyle.Fill;
        }

        private void BudgetTemplateWizard_Load(object sender, EventArgs e)
        {
            dataGridView1.EnableHeadersVisualStyles = false;

            dataGridView1.ColumnHeadersDefaultCellStyle.BackColor = Color.FromArgb(116, 86, 174);
            dataGridView1.ColumnHeadersDefaultCellStyle.Font = new Font("Nirmala UI", 8, FontStyle.Bold);
            dataGridView1.ColumnHeadersDefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;

            dataGridView1.DataSource = BudgetsRepository.Instance.LoadTemplates();
        }

        // Edit a template
        private void button2_Click(object sender, EventArgs e)
        {
            DataGridViewRow selectedRow = dataGridView1.SelectedRows[0];
            EditTemplateWizard editBudgetWizard = new EditTemplateWizard(selectedRow);
            editBudgetWizard.RefreshGridRequested += (s, args) =>
            {
                RefreshDataGrid();
            };

            panel1.Controls.Clear();
            panel1.Controls.Add(editBudgetWizard);
            editBudgetWizard.Dock = DockStyle.Fill;
        }
        public void RefreshDataGrid()
        {
            dataGridView1.DataSource = BudgetsRepository.Instance.LoadTemplates();
        }
    }
}
