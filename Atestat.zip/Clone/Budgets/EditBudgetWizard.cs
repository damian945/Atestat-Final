﻿using System;
using System.Windows.Forms;
using Atestat.Models;
using Atestat.Repos;

namespace Atestat.Budgets
{
    public partial class EditBudgetWizard: UserControl
    {
        public int budgetID;

        public EditBudgetWizard()
        {
            InitializeComponent();
        }

        public EditBudgetWizard(DataGridViewRow selectedRow) : this()
        {
            comboBox1.SelectedItem = selectedRow.Cells["Month"].Value.ToString();
            comboBox2.SelectedItem = selectedRow.Cells["Year"].Value.ToString();
            textBox3.Text = selectedRow.Cells["IncomeTarget"].Value.ToString();
            textBox4.Text = selectedRow.Cells["SpendingLimit"].Value.ToString();
            textBox5.Text = selectedRow.Cells["SavingsTarget"].Value.ToString();

            budgetID = Convert.ToInt32(selectedRow.Cells["ID"].Value);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            var newBudget = new BudgetModel
            {
                BudgetMonth = comboBox1.SelectedItem?.ToString(),
                BudgetYear = comboBox2.SelectedItem?.ToString(),
                IncomeTarget = double.Parse(textBox3.Text),
                SpendingLimit = double.Parse(textBox4.Text),
                SavingsTarget = double.Parse(textBox5.Text)
            };


            BudgetsRepository.Instance.EditBudget(newBudget, budgetID);

            this.Controls.Clear();
            this.Controls.Add(new BudgetsDataGrid());
        }
    }
}
