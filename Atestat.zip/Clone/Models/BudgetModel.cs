﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Atestat.Models
{
    class BudgetModel
    {
        public string BudgetMonth { get; set; }
        public string BudgetYear { get; set; }
        public double IncomeTarget { get; set; }
        public double SpendingLimit { get; set; }
        public double SavingsTarget { get;set; }
    }
}
