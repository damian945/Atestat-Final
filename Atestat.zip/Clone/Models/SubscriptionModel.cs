﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Atestat.Models
{
    class SubscriptionModel
    {
        public int TransactionID { get; set; }
        public string SubscriptionName { get; set; }
        public decimal MonthlyCost { get; set; }
        public DateTime EndDate { get; set; }
        public string Status { get; set; }
    }
}
