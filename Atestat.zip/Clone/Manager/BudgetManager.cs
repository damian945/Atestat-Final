﻿using System;
using System.Data.OleDb;
using Atestat.Models;

namespace Atestat.Manager
{
    class BudgetManager
    {
        private string connectionString =
            @"Provider=Microsoft.Jet.OLEDB.4.0;Data Source=db_transactions.mdb";

        private BudgetManager()
        {
            LoadBudget();
        }

        // Singleton pattern
        private static BudgetManager _instance;
        public static BudgetManager Instance
        {
            get
            {
                if (_instance == null)
                    _instance = new BudgetManager();
                return _instance;
            }
        }

        // The current budget model
        public BudgetModel CurrentBudget { get; private set; }

        public void LoadBudget()
        {
            // Pseudo-code: check if custom budget exists for the month.
            CurrentBudget = CustomBudgetExists();
            if (CurrentBudget == null)
            {
                CurrentBudget = GetDefaultBudget();
            }
        }

        // Replace these with your actual data access implementations.
        private BudgetModel CustomBudgetExists()
        {
            string query = "SELECT [IncomeTarget], [SpendingLimit], [SavingsTarget] FROM [db_budgets] WHERE [BudgetMonth] = @Month " +
                "AND [BudgetYear] = @Year";

            using (OleDbConnection conn = new OleDbConnection(connectionString))
            {
                conn.Open();
                using (OleDbCommand command = new OleDbCommand(query, conn))
                {
                    // Add the parameters
                    command.Parameters.Add("@Month", OleDbType.VarChar, 20).Value = DateTime.Now.ToString("MMMM");
                    command.Parameters.Add("@Year", OleDbType.VarChar, 20).Value = DateTime.Now.ToString("yyyy");

                    using (OleDbDataReader reader = command.ExecuteReader())
                    {
                        if (reader.Read())
                        {
                            // Create a Budget instance and populate it with data from the reader.
                            BudgetModel customBudget = new BudgetModel
                            {
                                // For example, assuming your table has a BudgetAmount column.
                                IncomeTarget = Convert.ToDouble(reader["IncomeTarget"]),
                                SpendingLimit = Convert.ToDouble(reader["SpendingLimit"]),
                                SavingsTarget = Convert.ToDouble(reader["SavingsTarget"])
                            };

                            return customBudget;
                        }
                    }
                }
            }

            // Check in the custom budgets database
            return null;
        }

        public BudgetModel GetDefaultBudget()
        {
            string query = "SELECT [IncomeTarget], [SpendingLimit], [SavingsTarget] FROM [db_defaultBudget]";

            using (OleDbConnection conn = new OleDbConnection(connectionString))
            {
                conn.Open();
                using (OleDbCommand command = new OleDbCommand(query, conn))
                {
                    using (OleDbDataReader reader = command.ExecuteReader())
                    {
                        if (reader.Read())
                        {
                            // Create a Budget instance and populate it with data from the reader.
                            BudgetModel defBudget = new BudgetModel
                            {
                                // For example, assuming your table has a BudgetAmount column.
                                IncomeTarget = Convert.ToDouble(reader["IncomeTarget"]),
                                SpendingLimit = Convert.ToDouble(reader["SpendingLimit"]),
                                SavingsTarget = Convert.ToDouble(reader["SavingsTarget"])
                            };

                            return defBudget;
                        }
                    }
                }
                throw new Exception("Default budget not set");
            }
        }

        public BudgetModel GetSpecificBudget(string month, string year)
        {
            string query = "SELECT [IncomeTarget], [SpendingLimit], [SavingsTarget] FROM [db_budgets] WHERE [BudgetMonth] = @Month " +
                            "AND [BudgetYear] = @Year";

            using (OleDbConnection conn = new OleDbConnection(connectionString))
            {
                conn.Open();
                using (OleDbCommand command = new OleDbCommand(query, conn))
                {
                    // Add the parameters
                    command.Parameters.Add("@Month", OleDbType.VarChar, 20).Value = month;
                    command.Parameters.Add("@Year", OleDbType.VarChar, 20).Value = year;

                    using (OleDbDataReader reader = command.ExecuteReader())
                    {
                        if (reader.Read())
                        {
                            // Create a Budget instance and populate it with data from the reader.
                            BudgetModel customBudget = new BudgetModel
                            {
                                // For example, assuming your table has a BudgetAmount column.
                                IncomeTarget = Convert.ToDouble(reader["IncomeTarget"]),
                                SpendingLimit = Convert.ToDouble(reader["SpendingLimit"]),
                                SavingsTarget = Convert.ToDouble(reader["SavingsTarget"])
                            };

                            return customBudget;
                        }
                    }
                }
            }

            // Check in the custom budgets database
            return null;
        } 
    }
}
