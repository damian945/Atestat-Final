﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Atestat.Models;
using Atestat.Repos;

namespace Atestat.Transactions
{
    public partial class EditSubscriptionWizard: Form
    {
        public int subscriptionID;

        public EditSubscriptionWizard()
        {
            InitializeComponent();
        }

        // Constructor overload
        public EditSubscriptionWizard(DataGridViewRow selectedRow) : this()
        {
            textBox1.Text = selectedRow.Cells["Name"].Value.ToString();
            SbDatePicker.Value = Convert.ToDateTime(selectedRow.Cells["EndDate"].Value);
            textBox2.Text = selectedRow.Cells["MonthlyCost"].Value.ToString();
            comboBox1.SelectedItem = selectedRow.Cells["Status"].Value.ToString();

            subscriptionID = Convert.ToInt32(selectedRow.Cells["ID"].Value);
        }

        private void EditSubscriptionWizard_Load(object sender, EventArgs e)
        {

        }

        // Edit Button
        private void AddSubscription_btn_Click(object sender, EventArgs e)
        {
            var newSubscription = new SubscriptionModel
            {
                SubscriptionName = textBox1.Text,
                MonthlyCost = decimal.Parse(textBox2.Text),
                EndDate = SbDatePicker.Value,
                Status = comboBox1.SelectedItem?.ToString()
            };

            SubscriptionRepository.Instance.EditSubscription(newSubscription, subscriptionID);

            this.DialogResult = DialogResult.OK;
            this.Close();
        }
    }
}
