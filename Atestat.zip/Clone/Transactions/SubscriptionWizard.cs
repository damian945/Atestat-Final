﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Atestat.Models;
using Atestat.Repos;

namespace Atestat.Transactions
{
    public partial class SubscriptionWizard: Form
    {
        public SubscriptionWizard()
        {
            InitializeComponent();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        // Add subscription Button
        private void AddSubscription_btn_Click(object sender, EventArgs e)
        {
            var subscription = new SubscriptionModel
            {
                SubscriptionName = textBox1.Text,
                MonthlyCost = decimal.Parse(textBox2.Text),
                EndDate = SbDatePicker.Value,
                Status = comboBox1.SelectedItem?.ToString()
            };

            SubscriptionRepository.Instance.InsertSubscription(subscription);

            this.DialogResult = DialogResult.OK;
            this.Close();
        }
    }
}
