﻿using Atestat.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Atestat.Transactions
{
    public partial class EditTransactionWizard: Form
    {
        public int transactionID;

        public EditTransactionWizard()
        {
            InitializeComponent();
        }

        // Adding the values from the selected row
        public EditTransactionWizard(DataGridViewRow selectedRow) : this()
        {
            dateTimePicker1.Value = Convert.ToDateTime(selectedRow.Cells["Date"].Value);
            comboBox1.SelectedItem = selectedRow.Cells["Type"].Value.ToString();
            comboBox2.SelectedItem = selectedRow.Cells["Category"].Value.ToString();
            textBox1.Text = selectedRow.Cells["Amount"].Value.ToString();
            textBox2.Text = selectedRow.Cells["Notes"].Value.ToString();

            transactionID = Convert.ToInt32(selectedRow.Cells["ID"].Value);
        }

        // Edit transaction button
        private void EditTransaction_Click(object sender, EventArgs e)
        {
            var newTransaction = new TransactionModel
            {
                DateOfTransaction = dateTimePicker1.Value,
                TransactionType = comboBox1.SelectedItem?.ToString(),  // "Expense" or "Income"
                CategoryID = (int)comboBox2.SelectedValue,    // if bound to a list with CategoryID
                Amount = decimal.Parse(textBox1.Text),
                Note = textBox2.Text
            };

            TransactionRepository.Instance.EditTransaction(newTransaction, transactionID);

            this.DialogResult = DialogResult.OK;
            this.Close();
        }

        // Sync the categories
        private void EditTransactionWizard_Load(object sender, EventArgs e)
        {
            var dt = TransactionRepository.Instance.GetCategories();

            comboBox2.DataSource = dt;
            comboBox2.DisplayMember = "CategoryName";
            comboBox2.ValueMember = "CategoryID";
        }
    }
}
